typedef struct
{
	int Data;
} LIST_NODE;


class LISTTYPE
{
private:
	int MAX=0;
	int Global_Position;
	LIST_NODE NODE[100];

public:
	bool Create(int n);
	int Get_ITEM(int n);
	bool IsEmpty();
	bool IsFull();
	bool Insert(int Position, int Data);
	bool Delete(int Position);
	bool Destroy();
};

extern LISTTYPE L;


#include "LIST.h"
#include <iostream>
using namespace std;

LISTTYPE L;

int main() {
	L.Create(3);
	L.Insert(0,10);
	L.Insert(1,10);
	L.Insert(0,30);
	L.Insert(2,40);
	L.Delete(3);
	L.Delete(2);
	L.Delete(1);
	L.Delete(0);
	L.Delete(1);
		
	cout << L.Get_ITEM(5);
	cout << L.Get_ITEM(1);
	L.Destroy();

	return 0;
}
#include "LIST.h"

bool LISTTYPE::Create(int n) {
	MAX = n;
	return true;
}
bool LISTTYPE::IsEmpty() {
	if (Global_Position == -1) return true;
	else return false;
}
bool LISTTYPE::IsFull() {
	if (Global_Position == MAX) return true;
	else return false;
}
int LISTTYPE::Get_ITEM(int n) {
	if (IsEmpty())return false;
	else return NODE[n - 1].Data;
}

bool LISTTYPE::Insert(int Position, int Data){
	if (IsFull())
		return false;
	else if ((Position > (Global_Position + 1)) || (Position < 0))
		return false;
	else
	{
		for (int i = Global_Position - 1; i > Position; i--) 
			NODE[i + 1].Data = NODE[i].Data;
		NODE[Position].Data = Data;
		Global_Position += 1;

		return true;
	}
}

bool LISTTYPE::Delete(int Position) {
	if (IsEmpty())
		return false;
	else if (Position == Global_Position - 1) {
		NODE[Position].Data = -100;
		Global_Position -= 1;
		return true;
	}
	else
	{
		for (int i = (Global_Position - 1); i >= (Position - 1); i--) {
			NODE[Position].Data = NODE[Position + 1].Data;
			Global_Position -= 1;
		}
		return true;
	}

}

bool LISTTYPE::Destroy() {
	return true;
}